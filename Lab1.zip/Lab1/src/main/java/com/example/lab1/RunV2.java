package com.example.lab1;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class RunV2 {
    public static void main(String[] args){
        // EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("ProjectCourseSys");

    }
}
