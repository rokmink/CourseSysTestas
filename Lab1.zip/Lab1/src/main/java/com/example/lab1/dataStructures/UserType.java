package com.example.lab1.dataStructures;

public enum UserType {
 ADMIN, NORMAL, EDITOR
}
