package com.example.lab1.dataStructures;

public class Constants {
    public static final String OUT_FILE="out.txt";
}
