package com.example.lab1.controllers;

import com.example.lab1.Start;
import com.example.lab1.dataStructures.CourseSystem;
import com.example.lab1.dataStructures.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import static com.example.lab1.dataStructures.Constants.OUT_FILE;

public class MainController implements Initializable {

    public PasswordField pswF;
    @FXML
public TextField loginData;
private CourseSystem courseSystem;
    private Connection connection;
    private PreparedStatement preparedStatement;
 @FXML void onRegButtonClick(ActionEvent event) throws IOException{

    FXMLLoader fxmlLoader = new FXMLLoader(Start.class.getResource("Registration-view.fxml"));
    Parent root = fxmlLoader.load();
    RegistrationController registrationController = fxmlLoader.getController();
    registrationController.setCourseSystem(courseSystem);

    Scene scene = new Scene(root);
    Stage stage = (Stage) loginData.getScene().getWindow();
    stage.setScene(scene);
    stage.show();
 }

    @FXML
    protected void onLoginButtonClick(ActionEvent event) throws IOException, SQLException {
        connection = DbUtills.connectToDb();
        String sql = "SELECT count(*) FROM user AS u WHERE u.login = ? AND u.password = ?";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, loginData.getText());
        preparedStatement.setString(2, pswF.getText());
        ResultSet rs = preparedStatement.executeQuery();
        while (rs.next()) {
            if (rs.getInt(1) > 0) {
                FXMLLoader fxmlLoader = new FXMLLoader(Start.class.getResource("User-view.fxml"));
                Parent root = fxmlLoader.load();

                UserViewController mainProjectsWindow = fxmlLoader.getController();

                // mainProjectsWindow.setProjectFormData(CourseSystem, loginData.getText());

                Scene scene = new Scene(root);

                Stage stage = (Stage) loginData.getScene().getWindow();

               // Stage stage = new Stage();
                stage.setTitle("Project Course System");
                stage.setScene(scene);
             //   stage.initModality(Modality.APPLICATION_MODAL);
              //  stage.showAndWait();
            } else {
                alertMessage("Neteisingas slapyvardis arba slaptažodis");
            }
      /*  User user = courseSystem.getAllUsers().stream().filter(c->c.getLogin().equals(loginData.getText())).filter((c->c.getPassword().equals(pswF.getText()))).findFirst().orElse(null);

        if(user != null)
        {
            FXMLLoader fxmlLoader = new FXMLLoader(Start.class.getResource("User-view.fxml"));
            Parent root=fxmlLoader.load();

            UserViewController userViewController = fxmlLoader.getController();
            //signUpForm.setCourseManagementSystem(courseManagementSystem);


            Scene scene = new Scene(root);
            Stage stage = (Stage) loginData.getScene().getWindow();
            stage.setScene(scene);
            stage.show();*/

        }
        /*else
        {

            alertMessage("Neteisingas slapyvardis arba slaptažodis");
        }*/


    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
     courseSystem= RW.loadFromFile(OUT_FILE);
        if(courseSystem==null){
            courseSystem= new CourseSystem(new ArrayList<User>());
        }
    }
   public void alertMessage(String s){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informacija");
        alert.setHeaderText("Pranešimas:");
        alert.setContentText(s);
        alert.initModality(Modality.APPLICATION_MODAL);

        alert.showAndWait();
    }
}



