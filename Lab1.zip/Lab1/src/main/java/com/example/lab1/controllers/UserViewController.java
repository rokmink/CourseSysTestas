package com.example.lab1.controllers;

import com.example.lab1.dataStructures.Person;
import com.example.lab1.dataStructures.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import org.hibernate.HibernateException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import static com.example.lab1.controllers.DbUtills.connectToDb;

public class UserViewController  {

    private String login;
    @FXML
    private TableView<User> user_table;

    @FXML
    private TableColumn<User, String> userName;

    @FXML
    private TableColumn<User, String> userLastname;

    public ObservableList<User> data;

    /*private List<User> initializeTable() {
          connectToDb();

        data = FXCollections.observableArrayList();

        HibernateTransaction hibernateTransaction = new HibernateTransaction();

        Iterator ite = hibernateTransaction.hibernateQuerry().list().iterator();
        while (ite.hasNext()) {
            User obj = (User) ite.next();

            data.add(obj);
        }



        return data;

    }*/
    public void logoff(ActionEvent event)throws IOException {
            Parent reg_scene_parent= FXMLLoader.load(getClass().getResource("Main-view.fxml"));
            Scene reg_scene=new Scene(reg_scene_parent);
            Stage app_stage=(Stage) ((Node) event.getSource()).getScene().getWindow();
            app_stage.setScene(reg_scene);
            app_stage.show();// neveikia dar
    }
    public void newProjectForm(ActionEvent actionEvent) throws IOException {
    /*    FXMLLoader fxmlLoader = new FXMLLoader(Start.class.getResource("New-project-form.fxml"));
        Parent root = fxmlLoader.load();

        NewProjectForm newProjectForm = fxmlLoader.getController();
        newProjectForm.setProjectFormData(login);

        Scene scene = new Scene(root);

        Stage stage = (Stage) myProjects.getScene().getWindow();
        stage.setScene(scene);
        stage.show();*/
       Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("New-project-form.fxml"));
        Stage stage = new Stage();
        stage.setTitle("Kursas");
        stage.setScene(new Scene(root, 450, 450));
        stage.show();
        // Hide this current window (if this is what you want)
        ((Node)(actionEvent.getSource())).getScene().getWindow().hide();

    }

    public void editUser(ActionEvent event) {

    }

}
